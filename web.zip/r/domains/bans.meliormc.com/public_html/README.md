litebans-php
===========

Web interface for [LiteBans](https://www.spigotmc.org/resources/litebans.3715/)

## User Contributed Translations
All translations in the "lang" folder have been contributed by users. Only the "en_US" locale will receive full support and updates.

I do not update these files -- even if I fully understood all of these languages, unfortunately I would not have the time to update all of the translations on my own, especially with the growing number of translations.

As a result, in the future, these translations may contain untranslated English text until they are updated.

Pull requests are welcome if you want to fix any problems with user contributed translations.
